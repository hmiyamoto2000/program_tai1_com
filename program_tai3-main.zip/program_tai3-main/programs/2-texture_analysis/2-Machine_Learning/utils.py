import csv
import math
import cv2
import numpy as np
from PIL import Image, ImageDraw
import os
import tifffile
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
import lightgbm as lgb
from matplotlib import pyplot as plt

####フォルダ作成関数
def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def xgboost_function(dataset, config):
    # データ形式の変換
    dtrain = xgb.DMatrix(dataset[0], dataset[1])
    dtest = xgb.DMatrix(dataset[2], dataset[3])

    # パラメータ設定
    # binary: 二値分類
    params = {
        "objective": config["objective"], #二項分類で確率を返す
        'learning_rate': config["learning_rate"],
        }

    # 履歴保存用の変数
    history = {}

    # 学習
    model = xgb.train(
        params = params,
        dtrain = dtrain,
        evals = [(dtrain, "train"), (dtest, "test")],
        evals_result = history,
        num_boost_round = config["num_boost_round"], #学習回数
        early_stopping_rounds = config["early_stopping_rounds"], #early_stopping
    )

    # Feature importanceは目的変数が何回分岐に使われているか
    # "weight "は、ある特徴がツリーに現れる回数である。
    # "gain" は、その特徴を使った分割の平均利得。gainの方が目的関数に対する改善度合いを出すのでこっちの方がよさそう．

    #csvファイルに重要度を書き込む
    my_makedirs(config["output_data_root1"])
    weight_list = model.get_fscore()
    gain_list = model.get_score(importance_type='gain') # https://note.com/y_katayama/n/n5882e9b2d15b
    sorted_weight_list = sorted(weight_list.items(), key=lambda x: x[1], reverse=True)  # 値でソート
    sorted_gain_list = sorted(gain_list.items(), key=lambda x: x[1], reverse=True)  # 値でソート


    #csvファイルを作成
    with open(config["output_data_root1"]+"Important_weight.csv",'w',newline='') as f:
        writer = csv.writer(f)
        names = ["Species", "value"]
        writer.writerow(names)
        for weight in sorted_weight_list:
            writer.writerow(weight)
    with open(config["output_data_root1"]+"Important_gain.csv",'w',newline='') as f:
        writer = csv.writer(f)
        names = ["Species", "value"]
        writer.writerow(names)
        for gain in sorted_gain_list:
            writer.writerow(gain)

    # 性能向上に寄与する度合いで重要度をプロット
    _, ax = plt.subplots(2, 1, figsize=(20, 20))
    xgb.plot_importance(model, ax=ax[0], importance_type='weight')#, show_values=False)
    xgb.plot_importance(model, ax=ax[1], importance_type='gain')#, show_values=False)
    plt.savefig(config["output_data_root1"] + "Important_features.png", format="png")
    plt.clf()

def random_forest_function(dataset, features, config):
    # ランダムフォレストの学習を行う
    my_makedirs(config["output_data_root2"])
    rfc = RandomForestClassifier(n_estimators=500, criterion='gini', max_depth=None)
    rfc.fit(dataset[0], dataset[1])

    # Feature Importance
    fti = rfc.feature_importances_   

    feature_dict = {}
    for i, feat in enumerate(features):
        dict = {feat: fti[i]}
        feature_dict.update(dict)
    sorted_important_list = sorted(feature_dict.items(), key=lambda x: x[1], reverse=True)  # 値でソート

    #csvファイルを作成
    with open(config["output_data_root2"]+"Important_feature.csv",'w',newline='') as f:
        writer = csv.writer(f)
        names = ["Species", "value"]
        writer.writerow(names)
        for important in sorted_important_list:
            writer.writerow(important)

    #グラフ表示
    importances = rfc.feature_importances_
    std = np.std([tree.feature_importances_ for tree in rfc.estimators_], axis=0)
    indices = np.argsort(importances)

    # 決定木の説明変数の重要度をデータフレーム化
    combined = list(zip(features, importances))
    sorted_combined = sorted(combined, key=lambda x: x[1])  # 値でソート
    features, importances = zip(*sorted_combined)

    plt.figure(figsize=(20,50))
    plt.title('Decision Tree - Feature Importance',fontsize=28)
    plt.barh(features, importances)
    plt.xlabel("Feature importance")
    plt.ylabel("Feature")
    plt.savefig(config["output_data_root2"] + "Important_features.png", format="png")
    plt.clf()

def lightgbm_function(dataset, features, config):
    # データ形式の変換
    lgb_train = lgb.Dataset(dataset[0], dataset[1])
    lgb_test = lgb.Dataset(dataset[2], dataset[3])

    # パラメータ設定
    # binary: 二値分類
    params = {
        "objective": "binary", #二項分類で確率を返す
        'learning_rate': config["learning_rate"],
        'metric': 'binary_logloss',
        #'boosting_type': 'gbdt',
        "num_leaves":3,
        "min_data_in_leaf":5,
        'random_state': 42,
        }

    # 学習
    model = lgb.train(
        params,
        train_set=lgb_train,
        valid_sets=lgb_test,
        num_boost_round = 200, #学習回数
        callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=1),
                    lgb.log_evaluation(10),], 
        # evals_result = history,
        
        # early_stopping_rounds = config["early_stopping_rounds"], #early_stopping
        )

    # Feature importanceは目的変数が何回分岐に使われているか
    # "weight "は、ある特徴がツリーに現れる回数である。
    # "gain" は、その特徴を使った分割の平均利得。gainの方が目的関数に対する改善度合いを出すのでこっちの方がよさそう．
    my_makedirs(config["output_data_root3"])
    split = model.feature_importance(importance_type='split')  
    gain = model.feature_importance(importance_type='gain') 

    feature_split_dict = {}
    feature_gain_dict = {}
    for i, feat in enumerate(features):
        dict = {feat: split[i]}
        feature_split_dict.update(dict)
    sorted_split_list = sorted(feature_split_dict.items(), key=lambda x: x[1], reverse=True)  # 値でソート

    for i, feat in enumerate(features):
        dict = {feat: gain[i]}
        feature_gain_dict.update(dict)
    sorted_gain_list = sorted(feature_gain_dict.items(), key=lambda x: x[1], reverse=True)  # 値でソート

    #csvファイルを作成
    with open(config["output_data_root3"]+"Important_split.csv",'w',newline='') as f:
        writer = csv.writer(f)
        names = ["Species", "value"]
        writer.writerow(names)
        for weight in sorted_split_list:
            writer.writerow(weight)
    with open(config["output_data_root3"]+"Important_gain.csv",'w',newline='') as f:
        writer = csv.writer(f)
        names = ["Species", "value"]
        writer.writerow(names)
        for gain in sorted_gain_list:
            writer.writerow(gain)

    # 性能向上に寄与する度合いで重要度をプロット
    _, ax = plt.subplots(2, 1, figsize=(20, 20))
    lgb.plot_importance(model, ax=ax[0], importance_type='split')#, show_values=False)
    lgb.plot_importance(model, ax=ax[1], importance_type='gain')#, show_values=False)
    plt.savefig(config["output_data_root3"] + "Important_features.png", format="png")
    plt.clf()